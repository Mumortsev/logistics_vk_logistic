# ВК-Логистик

Next.js 15 + TypeScript, Motion, Leaflet/OpenStreetMap, Photon, OSRM, Lucide.

## Запуск

```bash
npm install
cp .env.example .env.local
npm run dev
```

Откройте http://localhost:3000. Для сборки: `npm run build && npm start`.

## Vercel

Загрузите репозиторий в GitHub, импортируйте в Vercel как Next.js, укажите переменные из `.env.example` в Project Settings → Environment Variables, выполните Deploy. Не используйте статический экспорт: проект содержит серверные маршруты.

## Конфигурация

- `lib/config.ts`: компания, демонстрационные тарифы, коэффициенты, минимальная стоимость.
- `PHOTON_URL`: Photon API, по умолчанию публичный демонстрационный сервер.
- `OSRM_URL`: OSRM API, по умолчанию публичный демонстрационный сервер.
- `TELEGRAM_BOT_TOKEN`, `TELEGRAM_CHAT_ID`: при наличии отправляют заявку в Telegram; без них сервер возвращает 503, а интерфейс показывает ошибку.
- Изображения загружаются с Unsplash, нужны проверка лицензий конкретных изображений и замена на согласованные фирменные фото.

## API

- `GET /api/geocode?q=...` — поиск населённых пунктов с кешированием Next.js.
- `GET /api/route?a=lng,lat&b=lng,lat` — дорожный маршрут и геометрия.
- `POST /api/lead` — отправка заявки, только при настроенном Telegram.

## Перед коммерческим запуском

1. Получить оригинал таблички: точный логотип, телефон, реквизиты, адрес; сверить услуги.
2. Утвердить реальные тарифы, коэффициенты, юридические документы и политику обработки персональных данных.
3. Настроить собственные или коммерческие геокодер, маршрутизатор и тайлы: публичные демо-серверы не гарантируют SLA и могут ограничивать запросы.
4. Подключить приём заявок и защиту от спама (rate limiting, captcha, логирование и политика хранения).
5. Провести полноценные интеграционные и браузерные тесты на целевых устройствах, включая малые населённые пункты, трансграничные маршруты и отказ сервисов.
6. Проверить доступность/корректность географических данных в нужных странах; Photon не гарантирует полноту всей базы СНГ.

## Open source и лицензии

- [Motion](https://github.com/motiondivision/motion) — MIT, используется.
- [Leaflet](https://github.com/Leaflet/Leaflet) — BSD-2-Clause, используется.
- [React Leaflet](https://github.com/PaulLeCam/react-leaflet) — Hippocratic License 3.0, используется; проверить пригодность лицензии для коммерческого проекта перед релизом.
- [Lucide](https://github.com/lucide-icons/lucide) — ISC, используется.
- [Photon](https://github.com/komoot/photon) — Apache-2.0, внешний API.
- [OSRM](https://github.com/Project-OSRM/osrm-backend) — BSD-2-Clause, внешний API.
- [Madar](https://github.com/zain-zaqout/madar) — MIT, референс без копирования кода.
- [shadcn/ui](https://github.com/shadcn-ui/ui) — MIT, исследован, не установлен.
- [react-three-fiber](https://github.com/pmndrs/react-three-fiber) — MIT, не используется: тяжёлое 3D не требуется.

Данные OpenStreetMap — ODbL; атрибуция на карте включена. Публичные тайлы `tile.openstreetmap.org` не предназначены для безусловной производственной нагрузки.
